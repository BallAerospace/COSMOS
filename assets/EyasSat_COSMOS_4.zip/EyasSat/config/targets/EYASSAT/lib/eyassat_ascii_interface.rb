require 'cosmos/interfaces/serial_interface'

module Cosmos

  class EyassatProtocol < Protocol
    def initialize(board_mode)
      super()
      @board_mode = board_mode
    end

    def write_packet(packet)
      data = ''
      packet.sorted_items.each do |item|
        value = packet.read_item(item, :RAW)
        if item.data_type == :STRING
          data << value
        else
          data << value.to_s
        end
      end
      if @board_mode and (data[0] == 'a' or data[0] == 'p')
        data = data[1..-1]
      end
      packet = Packet.new(nil, nil)
      packet.buffer = data
      packet
    end
  end

  class EyassatAsciiInterface < SerialInterface

    WRITE_TERMINATION = '0x0D'
    READ_TERMINATION = '0x0A0D'

    INTERNAL_FIELDS = {
      'TelemDelay' => ['TLM_DELAY', :to_i],
      'CmdTimeOut' => ['CMD_TIMEOUT', :to_i],
      'Pwr' => ['PWR_TLM', :to_i],
      'ADCS' => ['ADCS_TLM', :to_i],
      'Exp1' => ['EXP_TLM', :to_i],
    }

    TEMPS_FIELDS = {
      'DH' => ['DH_TEMP', :to_f],
      'Exp' => ['EXP_TEMP', :to_f],
      'Ref' => ['REF_TEMP', :to_f],
      'Panel_A' => ['PANEL_A_TEMP', :to_f],
      'Panel_B' => ['PANEL_B_TEMP', :to_f],
      'Base' => ['BASE_TEMP', :to_f],
      'Top_A' => ['TOP_A_TEMP', :to_f],
      'Top_B' => ['TOP_B_TEMP', :to_f],
    }

    POWER_FIELDS = {
      'Sep' => ['SEP_STATUS', :to_i],
      'V_Batt' => ['V_BATT', :to_f],
      'I_Batt' => ['I_BATT', :to_f],
      'V_SA' => ['V_SA', :to_f],
      'I_SA' => ['I_SA', :to_f],
      'I_MB' => ['I_MB', :to_f],
      'V_5v' => ['V_5V', :to_f],
      'I_5v' => ['I_5V', :to_f],
      'V_3v' => ['V_3V', :to_f],
      'I_3v' => ['I_3V', :to_f],
      'S' => ['SWITCH_STATUS', :from_hex],
      'T_Batt' => ['BATT_TEMP', :to_f],
      'T_SA1' => ['SA1_TEMP', :to_f],
      'T_SA2' => ['SA2_TEMP', :to_f],
    }

    POWER_UNSCALED_FIELDS = {
      'Sep' => ['SEP_STATUS', :to_i],
      'V_Batt' => ['V_BATT', :to_i],
      'I_Batt' => ['I_BATT', :to_i],
      'V_SA' => ['V_SA', :to_i],
      'I_SA' => ['I_SA', :to_i],
      'I_MB' => ['I_MB', :to_i],
      'V_5v' => ['V_5V', :to_i],
      'I_5v' => ['I_5V', :to_i],
      'V_3v' => ['V_3V', :to_i],
      'I_3v' => ['I_3V', :to_i],
      'S' => ['SWITCH_STATUS', :from_hex],
      'T_Batt' => ['BATT_TEMP', :to_i],
      'T_SA1' => ['SA1_TEMP', :to_i],
      'T_SA2' => ['SA2_TEMP', :to_i],
    }

    ADCS_FIELDS = {
      's_T' => ['SUN_TOP', :to_i],
      's_B' => ['SUN_BOTTOM', :to_i],
      's0' => ['SUN_0', :to_i],
      's90' => ['SUN_90', :to_i],
      's180' => ['SUN_180', :to_i],
      's270' => ['SUN_270', :to_i],
      'ya' => ['YAW_ANG', :to_f],
      'sa' => ['SUN_OFFSET', :to_f],
      'M_X' => ['MAG_X', :to_f],
      'M_Y' => ['MAG_Y', :to_f],
      'M_Z' => ['MAG_Z', :to_f],
      'A_X' => ['ACC_X', :to_f],
      'A_Y' => ['ACC_Y', :to_f],
      'A_Z' => ['ACC_Z', :to_f],
      'X' => ['X_ROD', :to_i],
      'Y' => ['Y_ROD', :to_i],
      'rps_out' => ['ACT_WHEEL_SPD', :to_f],
      'rps_cmd' => ['CMD_WHEEL_SPD', :to_f],
      'PWM_out' => ['PWM', :to_i],
      'alg' => ['CTRL_ALG', :to_i],
      'P' => ['P_CONST', :to_f],
      'I' => ['I_CONST', :to_f],
      'D' => ['D_CONST', :to_f],
      'deltaT' => ['DELTA_T', :to_i],
      'db' => ['DEADBAND', :to_f],
      'g' => ['SLOPE', :to_f],
      'SunA' => ['OFFSET', :to_f],
      'e' => ['EXTRA', :to_f],
      'hyst' => ['RPS_HYST', :to_f],
    }

    def initialize(com_port, read_timeout = nil, board_mode = false, baud_rate = 19200)
      super(com_port, com_port, baud_rate.to_i, 'NONE', 1, 10, read_timeout, 'TERMINATED', WRITE_TERMINATION, READ_TERMINATION)
      @board_mode = ConfigParser.handle_true_false(board_mode)
      @queue = Queue.new
      add_protocol(EyassatProtocol, [@board_mode], :WRITE)
    end

    def connect
      super()
      @internal_packet = System.telemetry.packet(@target_names[0], 'INTERNAL').clone
      @temps_packet = System.telemetry.packet(@target_names[0], 'TEMPS').clone
      @power_packet = System.telemetry.packet(@target_names[0], 'POWER').clone
      @power_unscaled_packet = System.telemetry.packet(@target_names[0], 'POWER_UNSCALED').clone
      @adcs_packet = System.telemetry.packet(@target_names[0], 'ADCS').clone
      @message_packet = System.telemetry.packet(@target_names[0], 'MESSAGE').clone
    end

    def read
      while 1
        return @queue.pop if @queue.length > 0
        packet = super()
        if packet
          # Queue Raw Packet
          raw_packet = packet.clone
          raw_packet.buffer = raw_packet.buffer(false) << "\x0A\x0D"
          @queue.push(raw_packet)

          # Interpret Packet
          string = packet.buffer
          packet_name = nil
          if !@board_mode
            if string[0..1] == 'ES'
              packet_name = string[13]
            end
          else
            if string[1] == ':'
              packet_name = string[0]
            elsif string[0..3] != 'ADCS' and string[0..4] != 'Power'
              packet_name = 'R'
            end
          end

          case packet_name
          when 'I'
            # Internal
            packet = convert_packet(string, @internal_packet.clone, 1, INTERNAL_FIELDS, /Exp1=-?\d/)
            return packet if packet

          when 'T'
            # Temps
            packet = convert_packet(string, @temps_packet.clone, 2, TEMPS_FIELDS, /Top_B=-?\d+\.\d+/)
            return packet if packet

          when 'P'
            # Power
            scaled = true
            split_string = string.split
            split_string[3..-1].each do |key_value|
              key, value = key_value.split('=')
              if key and value and key == 'V_5v'
                scaled = false if value.to_i > 10
                break
              end
            end
            if scaled
              packet = convert_packet(string, @power_packet.clone, 3, POWER_FIELDS, /T_SA2=-?\d+\.\d+/)
            else
              packet = convert_packet(string, @power_unscaled_packet.clone, 4, POWER_UNSCALED_FIELDS, /T_SA2=-?\d+/)
            end
            return packet if packet

          when 'A'
            # ADCS
            packet = convert_packet(string, @adcs_packet.clone, 5, ADCS_FIELDS, /hyst=-?\d+\.\d+/)
            return packet if packet

          when 'R'
            # Response Message
            packet = @message_packet.clone
            packet.received_time = nil
            split_string = string.split
            if @board_mode
              packet.write('PACKET_ID', 6)
              packet.write('CALL_SIGN', '')
              packet.write('TIME_STRING', '')
              if split_string.length >= 1
                packet.write('MESSAGE', split_string[0..-1].join(" "))
              else
                packet.write('MESSAGE', '')
              end
            else
              packet.write('PACKET_ID', 6)
              if split_string[0].length <= 3
                packet.write('CALL_SIGN', split_string[0])
              else
                next
              end
              if split_string[1].length == 8
                packet.write('TIME_STRING', split_string[1])
              else
                next
              end
              if split_string.length >= 4
                packet.write('MESSAGE', split_string[3..-1].join(" "))
              else
                packet.write('MESSAGE', '')
              end
            end
            return packet if packet

          when '-', '', nil
            # Ignore ---- messages

          else
            # Assume its a message and capture the whole thing
            packet = @message_packet.clone
            packet.received_time = nil
            split_string = string.split
            packet.write('PACKET_ID', 6)
            packet.write('CALL_SIGN', '')
            packet.write('TIME_STRING', '')
            if split_string.length >= 1
              packet.write('MESSAGE', split_string[0..-1].join(" "))
            else
              packet.write('MESSAGE', '')
            end
            return packet if packet
          end

        else # if packet
          return nil

        end # if packet
      end
    end

    protected

    def convert_packet(string, packet, packet_id, fields, validity_check)
      return nil unless string =~ validity_check
      packet.received_time = nil
      split_string = string.split
      packet.write('PACKET_ID', packet_id)
      if @board_mode
        packet.write('CALL_SIGN', '')
        packet.write('TIME_STRING', '')
        first_key_offset = 1
      else
        if split_string[0].length <= 3
          packet.write('CALL_SIGN', split_string[0])
        else
          return nil
        end
        if split_string[1].length == 8
          packet.write('TIME_STRING', split_string[1])
        else
          return nil
        end
        first_key_offset = 3
      end
      split_string[first_key_offset..-1].each do |key_value|
        key, value = key_value.split('=')
        if key and value
          value = value[0..-2] if value[-1] == ','
          item_name, to_method = fields[key]
          if to_method == :from_hex
            packet.write(item_name, Integer(value)) if item_name
          else
            packet.write(item_name, value.send(to_method)) if item_name
          end
        end
      end
      packet
    end

  end # class EyassatAsciiInterface

end # module Cosmos
