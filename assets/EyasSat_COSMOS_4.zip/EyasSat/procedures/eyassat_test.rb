load 'cosmos/tools/test_runner/test.rb'

EYASSAT_CMD_DELAY = 3
EYASSAT_WAIT_CHECK_DELAY = 15

class InternalTest < Cosmos::Test

  def test_01_tlm_delay
    cmd("EYASSAT TLM_DELAY with DELAY 1")
    wait_check("EYASSAT INTERNAL TLM_DELAY == 1", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT TLM_DELAY with DELAY 2")
    wait_check("EYASSAT INTERNAL TLM_DELAY == 2", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT TLM_DELAY with DELAY 1")
    wait_check("EYASSAT INTERNAL TLM_DELAY == 1", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_02_cmd_timeout
    cmd("EYASSAT CMD_TIMEOUT with TIMEOUT 1")
    wait_check("EYASSAT INTERNAL CMD_TIMEOUT == 1", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT CMD_TIMEOUT with TIMEOUT 2")
    wait_check("EYASSAT INTERNAL CMD_TIMEOUT == 2", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT CMD_TIMEOUT with TIMEOUT 1")
    wait_check("EYASSAT INTERNAL CMD_TIMEOUT == 1", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_03_exp_tlm_on_off
    cmd("EYASSAT EXP_TLM with ENABLE ON")
    wait("EYASSAT MESSAGE MESSAGE == 'Exp#1 Module Unattached'", 5)
    wait_check("EYASSAT INTERNAL EXP_TLM == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT EXP_TLM with ENABLE OFF")
    wait_check("EYASSAT INTERNAL EXP_TLM == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_04_hour
    cmd("EYASSAT HOUR with HOUR 2")
    wait(EYASSAT_CMD_DELAY)
    time_string = tlm("EYASSAT INTERNAL TIME_STRING")
    unless time_string[0..1] == '02'
      raise "Hour not set to 02"
    end
    cmd("EYASSAT HOUR with HOUR 3")
    wait(EYASSAT_CMD_DELAY)
    time_string = tlm("EYASSAT INTERNAL TIME_STRING")
    unless time_string[0..1] == '03'
      raise "Hour not set to 03"
    end
  end

  def test_05_minute
    cmd("EYASSAT MINUTE with MINUTE 2")
    wait(EYASSAT_CMD_DELAY)
    time_string = tlm("EYASSAT INTERNAL TIME_STRING")
    unless time_string[3..4] == '02'
      raise "Minute not set to 02"
    end
    cmd("EYASSAT MINUTE with MINUTE 30")
    wait(EYASSAT_CMD_DELAY)
    time_string = tlm("EYASSAT INTERNAL TIME_STRING")
    unless time_string[3..4] == '30'
      raise "Minute not set to 30"
    end
  end

  def test_06_second
    cmd("EYASSAT SECOND with SECOND 2")
    wait(EYASSAT_CMD_DELAY)
    time_string = tlm("EYASSAT INTERNAL TIME_STRING")
    unless time_string[6..7] == '02' or time_string[6..7] == '03' or time_string[6..7] == '04' or time_string[6..7] == '05' or time_string[6..7] == '06'
      raise "Second not set to 02"
    end
    cmd("EYASSAT SECOND with SECOND 30")
    wait(EYASSAT_CMD_DELAY)
    time_string = tlm("EYASSAT INTERNAL TIME_STRING")
    unless time_string[6..7] == '30' or time_string[6..7] == '31' or time_string[6..7] == '32' or time_string[6..7] == '33' or time_string[6..7] == '34'
      raise "Second not set to 30"
    end
  end

  def test_07_call_sign
    cmd("EYASSAT CALL_SIGN with CALL_SIGN 0")
    wait_check("EYASSAT INTERNAL CALL_SIGN == 'ES0'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT CALL_SIGN with CALL_SIGN 1")
    wait_check("EYASSAT INTERNAL CALL_SIGN == 'ES1'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT CALL_SIGN with CALL_SIGN 0")
    wait_check("EYASSAT INTERNAL CALL_SIGN == 'ES0'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_08_direct_string
    cmd("EYASSAT STRING with STRING 'it1'")
    wait_check("EYASSAT INTERNAL CMD_TIMEOUT == 1", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT STRING with STRING 'it2'")
    wait_check("EYASSAT INTERNAL CMD_TIMEOUT == 2", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT STRING with STRING 'it1'")
    wait_check("EYASSAT INTERNAL CMD_TIMEOUT == 1", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_09_pwr_tlm_on_off
    cmd("EYASSAT PWR_TLM with ENABLE ON")
    wait_check("EYASSAT INTERNAL PWR_TLM == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_TLM with ENABLE OFF")
    wait_check("EYASSAT INTERNAL PWR_TLM == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_TLM with ENABLE ON")
    wait_check("EYASSAT INTERNAL PWR_TLM == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_10_adcs_tlm_on_off
    cmd("EYASSAT ADCS_TLM with ENABLE ON")
    wait_check("EYASSAT INTERNAL ADCS_TLM == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_TLM with ENABLE OFF")
    wait_check("EYASSAT INTERNAL ADCS_TLM == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_TLM with ENABLE ON")
    wait_check("EYASSAT INTERNAL ADCS_TLM == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_11_other_telemetry
    # Check other telemetry points in INTERNAL
    check("EYASSAT INTERNAL RECEIVED_TIMESECONDS")
    check("EYASSAT INTERNAL RECEIVED_TIMEFORMATTED")
    check("EYASSAT INTERNAL RECEIVED_COUNT")
    check("EYASSAT INTERNAL PACKET_ID")
    check("EYASSAT INTERNAL CALL_SIGN")
    check("EYASSAT INTERNAL TIME_STRING")

    # Check other telemetry points in TEMPS
    check("EYASSAT TEMPS RECEIVED_TIMESECONDS")
    check("EYASSAT TEMPS RECEIVED_TIMEFORMATTED")
    check("EYASSAT TEMPS RECEIVED_COUNT")
    check("EYASSAT TEMPS PACKET_ID")
    check("EYASSAT TEMPS CALL_SIGN")
    check("EYASSAT TEMPS TIME_STRING")
    check("EYASSAT TEMPS DH_TEMP")
    check("EYASSAT TEMPS EXP_TEMP")
    check("EYASSAT TEMPS REF_TEMP")
    check("EYASSAT TEMPS PANEL_A_TEMP")
    check("EYASSAT TEMPS PANEL_B_TEMP")
    check("EYASSAT TEMPS BASE_TEMP")
    check("EYASSAT TEMPS TOP_A_TEMP")
    check("EYASSAT TEMPS TOP_B_TEMP")

    # Check other telemetry points in MESSAGE
    check("EYASSAT MESSAGE RECEIVED_TIMESECONDS")
    check("EYASSAT MESSAGE RECEIVED_TIMEFORMATTED")
    check("EYASSAT MESSAGE RECEIVED_COUNT")
    check("EYASSAT MESSAGE PACKET_ID")
    check("EYASSAT MESSAGE CALL_SIGN")
    check("EYASSAT MESSAGE TIME_STRING")
    check("EYASSAT MESSAGE MESSAGE")

    # Check other telemetry points in RAW
    check("EYASSAT RAW RECEIVED_TIMESECONDS")
    check("EYASSAT RAW RECEIVED_TIMEFORMATTED")
    check("EYASSAT RAW RECEIVED_COUNT")
    check("EYASSAT RAW STRING")
  end

end # class InternalTest

class PowerTest < Cosmos::Test

  def case_setup
    detect_board_test()
    unless @board_test
      on_off = tlm("EYASSAT INTERNAL PWR_TLM")
      if on_off != 'ON'
        cmd("EYASSAT PWR_TLM with ENABLE ON")
        wait_check("EYASSAT INTERNAL PWR_TLM == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
        wait(EYASSAT_CMD_DELAY)
      end
    end
  end

  def test_01_pwr_scale
    case_setup()
    count = tlm("EYASSAT POWER RECEIVED_COUNT")
    cmd("EYASSAT PWR_SCALE with ENABLE TRUE")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER RECEIVED_COUNT > #{count}", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    count = tlm("EYASSAT POWER_UNSCALED RECEIVED_COUNT")
    cmd("EYASSAT PWR_SCALE with ENABLE FALSE")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER_UNSCALED RECEIVED_COUNT > #{count}", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)

    # Check unscaled telemetry points in PWR
    check("EYASSAT POWER_UNSCALED RECEIVED_TIMESECONDS")
    check("EYASSAT POWER_UNSCALED RECEIVED_TIMEFORMATTED")
    check("EYASSAT POWER_UNSCALED RECEIVED_COUNT")
    check("EYASSAT POWER_UNSCALED PACKET_ID")
    check("EYASSAT POWER_UNSCALED CALL_SIGN")
    check("EYASSAT POWER_UNSCALED TIME_STRING")
    check("EYASSAT POWER_UNSCALED SEP_STATUS")
    check("EYASSAT POWER_UNSCALED V_BATT")
    check("EYASSAT POWER_UNSCALED I_BATT")
    check("EYASSAT POWER_UNSCALED V_SA")
    check("EYASSAT POWER_UNSCALED I_SA")
    check("EYASSAT POWER_UNSCALED I_MB")
    check("EYASSAT POWER_UNSCALED V_5V")
    check("EYASSAT POWER_UNSCALED I_5V")
    check("EYASSAT POWER_UNSCALED V_3V")
    check("EYASSAT POWER_UNSCALED I_3V")
    check("EYASSAT POWER_UNSCALED SWITCH_STATUS")
    check("EYASSAT POWER_UNSCALED BATT_TEMP")
    check("EYASSAT POWER_UNSCALED SA1_TEMP")
    check("EYASSAT POWER_UNSCALED SA2_TEMP")
    check("EYASSAT POWER_UNSCALED PWR_3V")
    check("EYASSAT POWER_UNSCALED PWR_ADCS")
    check("EYASSAT POWER_UNSCALED PWR_EXP")
    check("EYASSAT POWER_UNSCALED PWR_HTR1")
    check("EYASSAT POWER_UNSCALED PWR_HTR2")

    count = tlm("EYASSAT POWER RECEIVED_COUNT")
    cmd("EYASSAT PWR_SCALE with ENABLE TRUE")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER RECEIVED_COUNT > #{count}", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)

    # Check scaled telemetry points in PWR
    check("EYASSAT POWER RECEIVED_TIMESECONDS")
    check("EYASSAT POWER RECEIVED_TIMEFORMATTED")
    check("EYASSAT POWER RECEIVED_COUNT")
    check("EYASSAT POWER PACKET_ID")
    check("EYASSAT POWER CALL_SIGN")
    check("EYASSAT POWER TIME_STRING")
    check("EYASSAT POWER SEP_STATUS")
    check("EYASSAT POWER V_BATT")
    check("EYASSAT POWER I_BATT")
    check("EYASSAT POWER V_SA")
    check("EYASSAT POWER I_SA")
    check("EYASSAT POWER I_MB")
    check("EYASSAT POWER V_5V")
    check("EYASSAT POWER I_5V")
    check("EYASSAT POWER V_3V")
    check("EYASSAT POWER I_3V")
    check("EYASSAT POWER SWITCH_STATUS")
    check("EYASSAT POWER BATT_TEMP")
    check("EYASSAT POWER SA1_TEMP")
    check("EYASSAT POWER SA2_TEMP")
    check("EYASSAT POWER PWR_3V")
    check("EYASSAT POWER PWR_ADCS")
    check("EYASSAT POWER PWR_EXP")
    check("EYASSAT POWER PWR_HTR1")
    check("EYASSAT POWER PWR_HTR2")
  end

  def test_02_pwr_exp
    case_setup()
    cmd("EYASSAT PWR_EXP with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_EXP == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_EXP with STATE ON")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_EXP == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_EXP with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_EXP == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_03_pwr_htr1
    case_setup()
    cmd("EYASSAT PWR_HTR1 with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_HTR1 == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_HTR1 with STATE ON")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_HTR1 == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_HTR1 with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_HTR1 == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_04_pwr_htr2
    case_setup()
    cmd("EYASSAT PWR_HTR2 with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_HTR2 == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_HTR2 with STATE ON")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_HTR2 == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_HTR2 with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_HTR2 == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_05_pwr_3v
    case_setup()
    cmd("EYASSAT PWR_3V with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_3V == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_3V with STATE ON")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_3V == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_3V with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_3V == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_06_pwr_adcs
    case_setup()
    cmd("EYASSAT PWR_ADCS with STATE ON")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_ADCS == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_ADCS with STATE OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_ADCS == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT PWR_ADCS with STATE ON")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT POWER PWR_ADCS == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_07_pwr_reset
    case_setup()
    cmd("EYASSAT PWR_RESET")
    get_board_test_tlm() if @board_test
    wait(EYASSAT_CMD_DELAY)
    # TBD - Don't know how to tell if this did anything
  end

  def detect_board_test
    @board_test = false
    call_sign = tlm("EYASSAT POWER CALL_SIGN")

    # Detect if board testing by checking for a call sign
    @board_test = true if call_sign == ''
  end

  def get_board_test_tlm
    if @board_test
      wait(EYASSAT_CMD_DELAY)
      cmd("EYASSAT PWR_RQST")
      wait(EYASSAT_CMD_DELAY)
    end
  end

end # class PowerTest

class AdcsTest < Cosmos::Test

  def case_setup
    detect_board_test()
    unless @board_test
      on_off = tlm("EYASSAT POWER PWR_ADCS")
      if on_off != 'ON'
        cmd("EYASSAT PWR_ADCS with STATE ON")
        wait_check("EYASSAT POWER PWR_ADCS == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
        wait(EYASSAT_CMD_DELAY)
      end

      on_off = tlm("EYASSAT INTERNAL ADCS_TLM")
      if on_off != 'ON'
        cmd("EYASSAT ADCS_TLM with ENABLE ON")
        wait_check("EYASSAT INTERNAL ADCS_TLM == 'ON'", EYASSAT_WAIT_CHECK_DELAY)
        wait(EYASSAT_CMD_DELAY)
      end
    end
  end

  def test_01_adcs_deadband
    case_setup()
    cmd("EYASSAT ADCS_DEADBAND with DEADBAND 10.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS DEADBAND", 10.0, 0.1, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_DEADBAND with DEADBAND 5.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS DEADBAND", 5.0, 0.1, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_DEADBAND with DEADBAND 10.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS DEADBAND", 10.0, 0.1, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_02_adcs_delta_t
    case_setup()
    cmd("EYASSAT ADCS_DELTA_T with DELTA_T 1.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS DELTA_T", 1.0, 0.1, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_DELTA_T with DELTA_T 2.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS DELTA_T", 2.0, 0.1, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_DELTA_T with DELTA_T 1.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS DELTA_T", 1.0, 0.1, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_03_adcs_d_const
    case_setup()
    cmd("EYASSAT ADCS_D_CONST with D_CONST 0.1")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS D_CONST", 0.1, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_D_CONST with D_CONST 0.2")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS D_CONST", 0.2, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_D_CONST with D_CONST 0.1")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS D_CONST", 0.1, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_04_adcs_i_const
    case_setup()
    cmd("EYASSAT ADCS_I_CONST with I_CONST 0.1")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS I_CONST", 0.1, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_I_CONST with I_CONST 0.2")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS I_CONST", 0.2, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_I_CONST with I_CONST 0.1")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS I_CONST", 0.1, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_05_adcs_p_const
    case_setup()
    cmd("EYASSAT ADCS_P_CONST with P_CONST 2.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS P_CONST", 2.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_P_CONST with P_CONST 0.2")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS P_CONST", 0.2, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_P_CONST with P_CONST 2.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS P_CONST", 2.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_06_adcs_extra
    case_setup()
    cmd("EYASSAT ADCS_EXTRA with EXTRA 5.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS EXTRA", 5.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_EXTRA with EXTRA 10.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS EXTRA", 10.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_EXTRA with EXTRA 5.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS EXTRA", 5.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_07_adcs_offset
    case_setup()
    cmd("EYASSAT ADCS_OFFSET with OFFSET 30.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS OFFSET", 30.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_OFFSET with OFFSET 10.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS OFFSET", 10.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_OFFSET with OFFSET 30.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS OFFSET", 30.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_08_adcs_slope
    case_setup()
    cmd("EYASSAT ADCS_SLOPE with SLOPE 0.5")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS SLOPE", 0.5, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_SLOPE with SLOPE 5.5")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS SLOPE", 5.5, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_SLOPE with SLOPE 0.5")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS SLOPE", 0.5, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_09_adcs_wheel_spd
    case_setup()
    cmd("EYASSAT ADCS_WHEEL_SPD with SPD 0.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS CMD_WHEEL_SPD", 0.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    unless @board_test
      wait_check_tolerance("EYASSAT ADCS ACT_WHEEL_SPD", 0.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    end
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_WHEEL_SPD with SPD 20.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS CMD_WHEEL_SPD", 20.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    unless @board_test
      wait_check("EYASSAT ADCS ACT_WHEEL_SPD > 0.0", EYASSAT_WAIT_CHECK_DELAY)
    end
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_WHEEL_SPD with SPD 0.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS CMD_WHEEL_SPD", 0.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    unless @board_test
      wait_check_tolerance("EYASSAT ADCS ACT_WHEEL_SPD", 0.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    end
    wait(EYASSAT_CMD_DELAY)
  end

  def test_10_adcs_rps_hyst
    case_setup()
    cmd("EYASSAT ADCS_RPS_HYST with RPS_HYST 4.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS RPS_HYST", 4.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_RPS_HYST with RPS_HYST 5.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS RPS_HYST", 5.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_RPS_HYST with RPS_HYST 4.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS RPS_HYST", 4.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_11_adcs_x_rod
    case_setup()
    cmd("EYASSAT ADCS_X_ROD with X_ROD OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS X_ROD == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_X_ROD with X_ROD POS")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS X_ROD == 'POS'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_X_ROD with X_ROD NEG")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS X_ROD == 'NEG'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_X_ROD with X_ROD OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS X_ROD == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_12_adcs_y_rod
    case_setup()
    cmd("EYASSAT ADCS_Y_ROD with Y_ROD OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS Y_ROD == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_Y_ROD with Y_ROD POS")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS Y_ROD == 'POS'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_Y_ROD with Y_ROD NEG")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS Y_ROD == 'NEG'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_Y_ROD with Y_ROD OFF")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS Y_ROD == 'OFF'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_13_adcs_ctrl_alg
    case_setup()
    cmd("EYASSAT ADCS_CTRL_ALG with CTRL_ALG DEFAULT")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS CTRL_ALG == 'DEFAULT'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_CTRL_ALG with CTRL_ALG PID")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS CTRL_ALG == 'PID'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_CTRL_ALG with CTRL_ALG SUN")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS CTRL_ALG == 'SUN'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_CTRL_ALG with CTRL_ALG DEFAULT")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS CTRL_ALG == 'DEFAULT'", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_14_adcs_pwm
    case_setup()
    cmd("EYASSAT ADCS_PWM with PWM 0")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS PWM == 0", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_PWM with PWM 80")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS PWM == 80", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_PWM with PWM 0")
    get_board_test_tlm() if @board_test
    wait_check("EYASSAT ADCS PWM == 0", EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_15_adcs_sun_offset
    case_setup()
    cmd("EYASSAT ADCS_SUN_OFFSET with SUN_OFFSET 0.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS SUN_OFFSET", 0.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_SUN_OFFSET with SUN_OFFSET 100.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS SUN_OFFSET", 100.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
    cmd("EYASSAT ADCS_SUN_OFFSET with SUN_OFFSET 0.0")
    get_board_test_tlm() if @board_test
    wait_check_tolerance("EYASSAT ADCS SUN_OFFSET", 0.0, 0.01, EYASSAT_WAIT_CHECK_DELAY)
    wait(EYASSAT_CMD_DELAY)
  end

  def test_16_adcs_reset
    case_setup()
    cmd("EYASSAT ADCS_RESET")
    get_board_test_tlm() if @board_test
    wait(EYASSAT_CMD_DELAY)
    # TBD - Don't know how to tell if this did anything
  end

  def test_17_other_telemetry
    case_setup()
    check("EYASSAT ADCS RECEIVED_TIMESECONDS")
    check("EYASSAT ADCS RECEIVED_TIMEFORMATTED")
    check("EYASSAT ADCS RECEIVED_COUNT")
    check("EYASSAT ADCS PACKET_ID")
    check("EYASSAT ADCS CALL_SIGN")
    check("EYASSAT ADCS TIME_STRING")
    check("EYASSAT ADCS ACC_X")
    check("EYASSAT ADCS ACC_Y")
    check("EYASSAT ADCS ACC_Z")
    check("EYASSAT ADCS MAG_X")
    check("EYASSAT ADCS MAG_Y")
    check("EYASSAT ADCS MAG_Z")
    check("EYASSAT ADCS SUN_TOP")
    check("EYASSAT ADCS SUN_BOTTOM")
    check("EYASSAT ADCS SUN_0")
    check("EYASSAT ADCS SUN_90")
    check("EYASSAT ADCS SUN_180")
    check("EYASSAT ADCS SUN_270")
    check("EYASSAT ADCS YAW_ANG")
  end

  def detect_board_test
    @board_test = false
    call_sign = tlm("EYASSAT ADCS CALL_SIGN")

    # Detect if board testing by checking for a call sign
    @board_test = true if call_sign == ''
  end

  def get_board_test_tlm
    if @board_test
      wait(EYASSAT_CMD_DELAY)
      cmd("EYASSAT ADCS_RQST")
      wait(EYASSAT_CMD_DELAY)
    end
  end

end # class AdcsTest

class EyassatTestSuite < Cosmos::TestSuite
  def initialize
    super()
    add_test('InternalTest')
    add_test('PowerTest')
    add_test('AdcsTest')
  end
end
