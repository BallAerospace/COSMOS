# encoding: ascii-8bit

USER_VERSION = "1.1.0"
