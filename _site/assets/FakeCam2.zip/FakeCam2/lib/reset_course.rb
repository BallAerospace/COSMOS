require 'fileutils'

puts "Warning! This will delete all log files and reset the procedures directory!"
puts "Do you want to continue? (y/n)"
resp = gets

if resp.chomp == 'y'
  puts "Resetting course..."

  # Delete contents of log directory.
  #log_dir = File.expand_path(File.join('..', 'outputs', 'logs'))
  log_dir = "..\\outputs\\logs"
  puts "  Cleaning log files..."
  puts "  log_dir = #{log_dir}"
  begin
    FileUtils.chmod(777, log_dir)
    FileUtils.rm_rf(log_dir)
    FileUtils.mkdir_p(log_dir)
  rescue
  end

  # Delete contents of the procedures folder
  #proc_dir = File.expand_path(File.join('..', 'procedures'))
  proc_dir = "..\\procedures"
  puts "  Cleaning procedures..."
  puts "  proc_dir = #{proc_dir}"
  begin
    FileUtils.chmod(777, proc_dir)
    FileUtils.rm_rf(proc_dir)
    FileUtils.mkdir_p(proc_dir)
  rescue
  end

  # Seed example logs...
  #example_log_dir = File.expand_path(File.join('..', 'config', 'data', 'example_logs', '.'))
  example_log_dir = "..\\config\\data\\example_logs\\."
  puts "  Copying example logs..."
  puts "  example_log_dir = #{example_log_dir}"
  FileUtils.cp_r(example_log_dir, log_dir)

  # Seed procedures...
  #example_proc_dir = File.expand_path(File.join('..', 'config', 'data', 'script_backups', '.'))
  example_proc_dir = "..\\config\\data\\script_backups\\."
  puts "  Copying example scripts..."
  puts "  example_proc_dir = #{example_proc_dir}"
  FileUtils.cp_r(example_proc_dir, proc_dir)

else
  puts "Reset cancelled..."

end

puts "Press enter to close..."
gets
