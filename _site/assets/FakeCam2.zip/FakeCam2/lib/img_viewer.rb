# encoding: ascii-8bit

# Ball Aerospace & Technologies Corp. Proprietary Information
#
# The information contained herein is the private property of Ball Aerospace &
# Technologies Corp. that is being made available to the recipient under the
# terms of a nondisclosure agreement or by other special arrangement.  It may
# not be used, in whole or in part, except for the limited purpose for which it
# has been furnished. It may not be distributed or reproduced, except as
# specifically authorized by Ball Aerospace and with this legend conspicuously
# attached.  This information is exempt from public disclosure under 5 U.S.C.
# 552(b)(4), and its use by Government personnel is subject to the restrictions
# imposed by 18 U.S.C. 1905.
#
# This source code module was developed with funds provided by
# Capital funding under charge number 11418.13.001.

require 'cosmos'
Cosmos.catch_fatal_exception do
  require 'cosmos/gui/qt_tool'
  require 'cosmos/gui/dialogs/splash'
  require 'cosmos/gui/dialogs/cmd_tlm_raw_dialog'
  require 'cosmos/script'
end

module Cosmos

  # The ImgViewer is a custom application created for the COSMOS for I&T
  # training course.  The tool receives packets of image data generated
  # by the "FakeCam" simulated instrument.  It reassembles the packets
  # into .jpg images and displays them.
  class ImgViewer < QtTool

    def initialize(options)
      super(options)

      statusBar.showMessage("")
      @log_dir = System.instance.paths['LOGS']

      initialize_actions()
      initialize_menus()
      complete_initialize()

      @imageLabel = Qt::Label.new
      @imageLabel.backgroundRole = Qt::Palette::Dark
      @imageLabel.setSizePolicy(Qt::SizePolicy::Ignored, Qt::SizePolicy::Ignored)
      @imageLabel.scaledContents = true
      @imageLabel.pixmap = Qt::Pixmap.new(options.width, options.height)
      setCentralWidget(@imageLabel)

      image_thread()
    end # initialize

    def initialize_menus
      # File Menu
      @file_menu = menuBar.addMenu('&File')
      @file_menu.addAction(@exit_action)

      # Help Menu
      @about_string = "Image Viewer displays images captured by the FakeCam instrument."

      initialize_help_menu()
    end

    def image_thread
      @image_thread = Thread.new do
        begin

          # Loop forever
          loop do

            # Subscribe to get image data packets from the server...
            loop do
              begin
                @pkt_q = subscribe_packet_data([['FAKECAM', 'IMAGE_DATA']])
                write_status("Connected to CTS")
                break
              rescue DRb::DRbConnError
                write_status("Attempting to connect to CTS...")
                sleep(1)
                next
              end
            end

            # Init last image number so that we'll start processing
            # the first image we see.
            @last_img_num = -1
            @last_img_name = ''
            
            # Receive and process packets   
            loop do
              begin
                pkt = get_packet(@pkt_q, true)
              rescue ThreadError
                # Indicates the queue was empty.  Wait a little while and try again.
                sleep(0.1)
                next
              rescue DRb::DRbConnError
                # Indicates that the connection to the CTS was lost.  Break out
                # of this inner loop and attempt to reestablish.
                sleep(1)
                break
              rescue Exception => err
                write_status "#{err}"
                sleep(1)
                break
              end
              
              img_num = pkt.read('imagenum')
              img_num_pkts = pkt.read('numpkts')
              img_pkt_num = pkt.read('pktnum')
              img_pkt_bytes = pkt.read('pktbytes')
              img_name = pkt.read('imagename').strip
              image_file = File.join(@log_dir, img_name)
            
              if (img_num != @last_img_num) or (@last_img_name != img_name)
                @img_data = ""
                @last_img_num = img_num
                @last_img_name = img_name
                write_status("Receiving new image with image number: #{img_num}")
              end
              @img_data << pkt.read('imagedata')[0..(img_pkt_bytes-1)]
            
              if img_pkt_num >= img_num_pkts
                write_status("Received last packet in image")
                File.open(image_file, 'wb') {|file| file.write(@img_data)}

                Qt.execute_in_main_thread(true) do
                    image = Qt::Image.new(image_file)
                    pixmap = Qt::Pixmap.fromImage(image)
                    @imageLabel.pixmap = pixmap
                end
              end # end if img_pkt_num >= img_num_pkts
            end # end loop do (receive and process packets)  
          end # end loop do (loop forever)
        rescue Exception => error
          Cosmos.handle_fatal_exception(error)
        end
      end
    end

    # Write to the status bar.
    def write_status(status)
      Qt.execute_in_main_thread(true) do
        statusBar.showMessage(status)
      end
    end

    # Handle the window closing.
    def closeEvent(event)
      @image_thread.kill if @image_thread
      super(event)
    end

    # Initialize tool options.
    def self.run(option_parser = nil, options = nil)
      Cosmos.catch_fatal_exception do
        unless option_parser and options
          option_parser, options = create_default_options()
          options.width = 420
          options.height = 420
          options.remember_geometry = false
          options.title = "Image Viewer"
          options.auto_size = false
          options.config_file = nil
        end

        super(option_parser, options)
      end
    end

  end # class ImgViewer

end # module Cosmos
