# $Id$

# LEGAL_RB_CSU_COMMERCIAL
#
# Commercial Software Rights Notice
#
# This Computer Software Unit (CSU) was developed at private expense by 
# Ball Aerospace & Technologies Corp. and qualifies as commercial computer 
# software under the applicable acquisition regulations governing the 
# contract under which this software has been delivered.  Use, duplication,
# or disclosure is subject to the restrictions referenced in the Software 
# Rights Notice in the controlling CSU of the Computer Software Configuration
# Item of which this CSU is a part.   This is an unpublished work, copyright 2012, 
# Ball Aerospace & Technologies Corp.   With respect to non-Government 
# recipients, Ball Aerospace reserves all of its proprietary rights in this 
# software.
#
# LEGAL_END
#
# Author: Donald Hall
#
# This is a sample functional test for the FakeCam camera simulator
#

require 'cosmos/tools/test_runner/test'

class FakeCamFunctionalTest < Cosmos::Test

  def setup
    puts "Running FakeCamFunctionalTest setup"  
    puts "FakeCamFunctionalTest setup complete"
  end

  def teardown
    puts "Running FakeCamFunctionalTest teardown"
    puts "FakeCamFunctionalTest teardown complete"
  end

  def test_noop
    puts "Running test_noop"
    Cosmos::Test.puts "This test verifies requirement 1001"

    # Get the current command accept and reject counts
    cmd_acpt_cnt = tlm("FAKECAM HEALTH_STATUS CMDACCEPTCNT")
    cmd_rjct_cnt = tlm("FAKECAM HEALTH_STATUS CMDREJECTCNT")
    
    # Send the NOOP command
    cmd("FAKECAM NOOP")
    
    # Check that the command was accepted
    cmd_acpt_cnt += 1
    wait_check("FAKECAM HEALTH_STATUS CMDACCEPTCNT == #{cmd_acpt_cnt}", 5)
    wait_check("FAKECAM HEALTH_STATUS CMDREJECTCNT == #{cmd_rjct_cnt}", 5)

    puts "test_noop complete"
  end

  def test_shutter
    puts "Running test_shutter"
    Cosmos::Test.puts "This test verifies requirement 1002"

    # Send the command to close the shutter.
    if $manual
      cmd("FAKECAM SHUTTERPOS with POS 'CLOSED'")
    else
      cmd_no_hazardous_check("FAKECAM SHUTTERPOS with POS 'CLOSED'")
    end

    # Check that the shutter is closed.
    wait_check("FAKECAM HEALTH_STATUS SHUTTERPOS == 'CLOSED'", 5)

    # Let the cmd counters settle
    wait(2)
    
    # Get the current cmd accept/reject counts
    cmd_acpt_cnt = tlm("FAKECAM HEALTH_STATUS CMDACCEPTCNT")
    cmd_rjct_cnt = tlm("FAKECAM HEALTH_STATUS CMDREJECTCNT")
    
    # Send the command to open the shutter.
    if $manual
      cmd("FAKECAM SHUTTERPOS with POS 'OPEN'")
    else
      cmd_no_hazardous_check("FAKECAM SHUTTERPOS with POS 'OPEN'")
    end
    
    # Check that the command was accepted and that the shutter is open.
    cmd_acpt_cnt += 1
    wait_check("FAKECAM HEALTH_STATUS CMDACCEPTCNT == #{cmd_acpt_cnt}", 5)
    wait_check("FAKECAM HEALTH_STATUS CMDREJECTCNT == #{cmd_rjct_cnt}", 5)
    wait_check("FAKECAM HEALTH_STATUS SHUTTERPOS == 'OPEN'", 5)
    
    # Send the command to close the shutter.
    if $manual
      cmd("FAKECAM SHUTTERPOS with POS 'CLOSED'")
    else
      cmd_no_hazardous_check("FAKECAM SHUTTERPOS with POS 'CLOSED'")
    end
    
    # Check that the command was accepted and that the shutter is closed.
    cmd_acpt_cnt += 1
    wait_check("FAKECAM HEALTH_STATUS CMDACCEPTCNT == #{cmd_acpt_cnt}", 5)
    wait_check("FAKECAM HEALTH_STATUS CMDREJECTCNT == #{cmd_rjct_cnt}", 5)
    wait_check("FAKECAM HEALTH_STATUS SHUTTERPOS == 'CLOSED'", 5)

    puts "test_shutter complete"
  end

  def test_imaging
    puts "Running test_imaging"
    Cosmos::Test.puts "This test verifies requirement 1003"

    # Open the shutter
    if $manual
      cmd("FAKECAM SHUTTERPOS with POS 'OPEN'")
    else
      cmd_no_hazardous_check("FAKECAM SHUTTERPOS with POS 'OPEN'")
    end
    wait_check("FAKECAM HEALTH_STATUS SHUTTERPOS == 'OPEN'", 5)
    
    # Get the current cmd accept/reject counts and the current image count.
    cmd_acpt_cnt = tlm("FAKECAM HEALTH_STATUS CMDACCEPTCNT")
    cmd_rjct_cnt = tlm("FAKECAM HEALTH_STATUS CMDREJECTCNT")
    image_cnt    = tlm("FAKECAM HEALTH_STATUS IMAGECNT")
    
    # We'll take 5 images
    5.times do
      # Command the image collect
      cmd("FAKECAM TAKEIMAGE")
    
      # Check that the command was accepted.
      cmd_acpt_cnt += 1
      wait_check("FAKECAM HEALTH_STATUS CMDACCEPTCNT == #{cmd_acpt_cnt}", 5)
      wait_check("FAKECAM HEALTH_STATUS CMDREJECTCNT == #{cmd_rjct_cnt}", 5)
    
      # Wait for the image collect to start
      # Note:  if the image is small, we may never see this flag change, 
      # so we won't perform a wait_check, just a wait.
      wait("FAKECAM HEALTH_STATUS IMAGEINPROG == 'IMAGING'", 5)
    
      # Wait for the image collect to complete.
      wait_check("FAKECAM HEALTH_STATUS IMAGEINPROG == 'NOTIMAGING'", 30)
    
      # Check that the image count increased.
      image_cnt += 1
      wait_check("FAKECAM HEALTH_STATUS IMAGECNT == #{image_cnt}", 5)

      # Now we'll check to see that the file we received is correct.
      # Note that is is unlikely that we would actually check mission 
      # data by checking to see if it exactly matches some expected file.
      # This is just an example to show that COSMOS can open files and
      # perform tests upon the data within the context of a test script.
      # In a real system, the data might be tested with some external
      # tool, or there might be some elaborate code written to test it
      # from test runner.  Or, it may just be collected, and then analyzed
      # in post-processing after the script has been run.
      
      # Get the image name from the image data packet
      image_name = tlm("FAKECAM IMAGE_DATA IMAGENAME")
      
      # Use the image name to get the filename of the expected file
      # and the received file.
      expected_image_file = File.join(::Cosmos::USERPATH, 'config', 'data', 'images', image_name)
      received_image_file = File.join(::Cosmos::USERPATH, 'outputs', 'logs', image_name)

      puts "image_name = #{image_name}"
      puts "expected file = \"#{expected_image_file}\""
      puts "received file = \"#{received_image_file}\""
      
      # Read the expected data and the received data from the files
      expected_image_data = ''
      File.open(expected_image_file, 'rb'){|file| expected_image_data = file.read}
      received_image_data = ''
      File.open(received_image_file, 'rb'){|file| received_image_data = file.read}
      
      # Check that the expected data matches the received data
      if (expected_image_data == received_image_data)
        puts "Received image data in file #{received_image_file} matched expected image data in file #{expected_image_file}"
      else
        raise "Received image data in file #{received_image_file} did not match expected image data in file #{expected_image_file}"
      end
    end 
    
    # Close the shutter
    if $manual
      cmd("FAKECAM SHUTTERPOS with POS 'CLOSED'")
    else
      cmd_no_hazardous_check("FAKECAM SHUTTERPOS with POS 'CLOSED'")
    end
    wait_check("FAKECAM HEALTH_STATUS SHUTTERPOS == 'CLOSED'", 5)    

    puts "test_imaging complete"    
  end

end

