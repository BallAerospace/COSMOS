# $Id$

# LEGAL_RB_CSU_COMMERCIAL
#
# Commercial Software Rights Notice
#
# This Computer Software Unit (CSU) was developed at private expense by 
# Ball Aerospace & Technologies Corp. and qualifies as commercial computer 
# software under the applicable acquisition regulations governing the 
# contract under which this software has been delivered.  Use, duplication,
# or disclosure is subject to the restrictions referenced in the Software 
# Rights Notice in the controlling CSU of the Computer Software Configuration
# Item of which this CSU is a part.   This is an unpublished work, copyright 2012, 
# Ball Aerospace & Technologies Corp.   With respect to non-Government 
# recipients, Ball Aerospace reserves all of its proprietary rights in this 
# software.
#
# LEGAL_END
#
# Author: Donald Hall
#
# This is a sample test suite for the FakeCam camera simulator
#

require 'cosmos/tools/test_runner/test'
require_utility 'fakecam_functional_test'
require_utility 'fakecam_thermal_test'

class FakeCamTestSuite < Cosmos::TestSuite
  def initialize
    super()
    add_test('FakeCamFunctionalTest')
    add_test('FakeCamThermalTest')
  end

  def setup
    puts "Running FakeCamTestSuite setup"
  
    # Turn on the power
    cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
    wait_check("FAKECAMSTE HEALTH_STATUS PSENBL == 'ENBL'", 10)
    
    # Check that voltage and current are correct
    wait_check_tolerance("FAKECAMSTE HEALTH_STATUS PSVOLTAGE", 28.0, 0.1, 5)
    wait_check_tolerance("FAKECAMSTE HEALTH_STATUS PSCURRENT", 4.3, 0.1, 5)
    
    # Wait for the FakeCam to connect...
    wait_check_expression("interface_state('FAKECAMINT') == 'CONNECTED'", 5)
    
    # Let the system settle for a couple of seconds before starting tests
    wait(2.0)
  
    puts "FakeCamTestSuite setup complete"
  end

  def teardown
    puts "Running FakeCamTestSuite teardown"

    # Turn off the power
    cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")
    wait_check("FAKECAMSTE HEALTH_STATUS PSENBL == 'DSBL'", 5)
    
    # Check that voltage and current are correct
    wait_check_tolerance("FAKECAMSTE HEALTH_STATUS PSVOLTAGE", 0.0, 0.1, 5)
    wait_check_tolerance("FAKECAMSTE HEALTH_STATUS PSCURRENT", 0.0, 0.1, 5)

    puts "FakeCamTestSuite teardown complete"
  end
end
