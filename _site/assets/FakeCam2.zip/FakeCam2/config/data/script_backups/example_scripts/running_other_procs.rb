# Here we are requiring a utility file
# that has methods defined within it
require_utility("example_scripts/sample_util.rb")

# Now we're going to execute one of the methods
# from the utility file
util_method()

# Run an entire script
start("example_scripts/hello_world.rb")