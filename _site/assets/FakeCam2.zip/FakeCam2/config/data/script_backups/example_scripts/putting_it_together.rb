# Turn on FakeCam
cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")

# Check that power has been enabled and voltage/current levels are ok
wait_check("FAKECAMSTE HEALTH_STATUS PSENBL == 'ENBL'", 5)
wait_check_tolerance("FAKECAMSTE HEALTH_STATUS PSVOLTAGE", 28.0, 0.1, 5)
wait_check_tolerance("FAKECAMSTE HEALTH_STATUS PSCURRENT", 4.3, 0.1, 5)

# Wait a few seconds for the FakeCam Interface to connect.
wait(5.0)

# Store the current command accept count in a variable
cmd_acpt_count = tlm("FAKECAM HEALTH_STATUS CMDACCEPTCNT")

# Send a NOOP command
cmd("FAKECAM NOOP")

# This command should cause the command accept count to increment
cmd_acpt_count += 1

# Check that the command accept count does what it should
wait_check("FAKECAM HEALTH_STATUS CMDACCEPTCNT == #{cmd_acpt_count}", 5)

# Turn off FakeCam
cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")
