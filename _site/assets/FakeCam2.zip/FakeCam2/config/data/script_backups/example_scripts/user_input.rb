# This is an example of how to ask the operator to perform 
# a manual check and enter the result.  Note that we can
# use the script to check if the result is valid instead of 
# making the operator figure that out...
voltage = ask("Read voltage from meter and enter below")
check_expression("(4..5).include?(#{voltage})")

# Here we'll ask for a simlple yes or no to determine 
# whether or not we should continue.  If the operator
# answers 'y', we'll demonstrate a pop-up prompt.
input = ask_string("Continue? (y/n)")
if input == 'y'
  prompt("You have decided to continue!")
else
  puts("Exiting")
end