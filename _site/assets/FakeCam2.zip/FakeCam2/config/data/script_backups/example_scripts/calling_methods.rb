# Call the rand() function with an integer
# argument to get a random integer within
# 0 to arg
rand_num_1 = rand(10)

# Call the puts() function to print the random number
puts("Random number #1 is: #{rand_num_1}")

# Call the rand function again, this time
# without the optional argument.  This will
# generate a floating point random number
# between 0 and 1
rand_num_2 = rand()

# Print the second random number with puts()
puts("Random number #2 is: #{rand_num_2}")