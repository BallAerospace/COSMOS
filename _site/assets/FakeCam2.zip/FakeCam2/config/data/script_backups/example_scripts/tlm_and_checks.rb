# Turn on FakeCam
cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
wait(5)

# Look at the output to see the difference in how
# telemetry points are displayed...
check("FAKECAM THERMAL_STATUS TEMP1")
check_raw("FAKECAM THERMAL_STATUS TEMP1")
check_formatted("FAKECAM THERMAL_STATUS TEMP1")
check_with_units("FAKECAM THERMAL_STATUS TEMP1")

# Here is an example of how to use a check statement to
# check if some condition is true.  Note the second
# check will cause the script to stop in error.
# Click go to continue after this happens.
check("FAKECAM THERMAL_STATUS TEMP1 < 50.0")
check("FAKECAM THERMAL_STATUS TEMP1 > 50.0")

# Here is an example of the check_tolerance method,
# which is the preferred way to check floating-point values.
# In this case we're expecting the value to be 28.0 +/- 0.1
check_tolerance("FAKECAMSTE HEALTH_STATUS PSVOLTAGE", 28.0, 0.1)

# Here is an example of how to get telemetry and
# store it into a variable
temp1 = tlm("FAKECAM THERMAL_STATUS TEMP1")

# Here is an example of one way to use the check_expression
# method.  This is checking to see if the temperature stored 
# in the last step is within a range of expected values.
check_expression("(5.0..15.0).include?(#{temp1})") 

# Turn off FakeCam
cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")