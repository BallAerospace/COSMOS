# This is a complete, functional Ruby script!
puts("Hello World!")