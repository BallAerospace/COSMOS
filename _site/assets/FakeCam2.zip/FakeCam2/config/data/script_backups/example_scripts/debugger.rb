# This script is to be used to demonstrate
# some of the capabilities of the debugger.

my_var = rand(10)
puts("Set a breakpoint after this line.")

# While the script is stopped, inspect the current value of my_var
# and then set script runner to run in "step" mode
puts("Step though this line.")
puts("...and this one.")

# Now go back to "run" mode
puts("Run though this line.")
puts("...and this one.")
