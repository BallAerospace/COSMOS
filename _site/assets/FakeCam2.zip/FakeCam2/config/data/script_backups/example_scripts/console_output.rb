# Print a string
puts("Printing a string!")

# Different ways to print the value stored in a variable
value = 7
puts(value)
puts("Ruby way to print a variable inside a string: #{value}")
puts("Printf-like way to print a variable inside a string: %d" % value)

# Look at the output to see the difference between puts and print
# Note that we manually add a newline character after the last print!
puts("Puts!")
puts("Puts!")
puts("Puts!")
print("Print!")
print("Print!")
print("Print!\n")