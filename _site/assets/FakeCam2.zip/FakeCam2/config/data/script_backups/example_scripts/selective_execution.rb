# This script is to be used to demonstrate how to 
# selectively execute selected lines in a script.

puts("executing line 4")
puts("executing line 5")

cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
wait(5)

cmd("FAKECAM NOOP")
wait_check("FAKECAM HEALTH_STATUS CMDACCEPTCNT == 2", 5)

cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")

puts("executing line 15")
puts("executing line 16")