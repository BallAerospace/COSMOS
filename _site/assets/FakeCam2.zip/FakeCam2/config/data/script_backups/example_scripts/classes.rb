# We'll start by defining a very simple class to represent a rectangle
class Rectangle

  # The initialize method is called to create new instances
  # of a class
  def initialize(length, width)
    
    # These are instance variables, or attributes. That means
    # that each instance of this class that is created
    # will have its own copy of these variables.
    @length = length
    @width = width
  end

  # These code defines reader functions that we
  # can use to access our attributes.
  attr_reader :length, :width

  # This is an exmple of a method that
  # operates on the class attributes
  def area()
    return @length * @width
  end

  # Here is another example of a method that
  # operates on the class attributes
  def longest_side()
     return @length if @length > @width
     return @width
  end

end

# Now we'll create two different instances of our class
r1 = Rectangle.new(3,5)
r2 = Rectangle.new(4,2)

# Now we'll call some of the methods for our objects inside of
# puts statements.
# Check the output to see the results...
puts "Rectangle 1 has length: #{r1.length} and width: #{r1.width}"
puts "Rectangle 1 has area: #{r1.area}"
puts "Rectangle 1 has longest side: #{r1.longest_side}"
puts ""
puts "Rectangle 2 has length: #{r2.length} and width: #{r2.width}"
puts "Rectangle 2 has area: #{r2.area}"
puts "Rectangle 2 has longest side: #{r2.longest_side}"
 
