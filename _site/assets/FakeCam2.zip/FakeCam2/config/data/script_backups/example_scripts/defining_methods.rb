# Define a method with no parameters
def method_1()
  puts "Executing method_1"
end

# Define a method with two parameters
def method_2(name, val)
  puts "Executing method_2 with name = #{name} and val = #{val}"
end

# Execute the first method
method_1()

# Execute the second method
method_2('Fred', 5)