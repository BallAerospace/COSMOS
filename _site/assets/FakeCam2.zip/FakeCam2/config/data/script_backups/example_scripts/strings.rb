var = 5

# Look at the script output and note how the escape
# characters are handled differently in single-quote
# strings versus double-quote strings.
puts('This is a single quote string:\n\tvar = #{var}')
puts("This is a double quote string:\n\tvar = #{var}")
