# Here is an example if/elsif/else block.
# Note that if blocks don't have to have elsif or else clauses.
if (Time.now.hour < 12)
  puts("Good Morning")
elsif (Time.now.hour < 17)
  puts ("Good Afternoon")
else
  puts ("Good Evening")
end

# There are many, many ways to loop in Ruby.
# Here are a few different ways to write the same loop:

# Method #1
for i in 0..2
  puts "Loop #1, i = #{i}"
end

# Method #2
3.times do |i|
  puts "Loop #2, i = #{i}"
end

# Method #3
i = 0
while (i < 3)
  puts "Loop #3, i = #{i}"
  i += 1
end  
