# This script is filled with various errors that
# can be detected by Script Runner!

# This is an example of a syntax error that
# will be caught by the syntax checker.
# The following line is missing a paren.
puts("%d", (var1+7.0)*((var2-13.0)/(1.4+var3))))) 

# This is an example of a run-time error that
# will NOT be caught by the syntax checker.
# Note that the syntax here is perfectly valid.
# Ruby cannot know until it tries to execute this line
# that the variable on the right-hand side of the equal
# sign has not been initized.
some_var = undeclared_var

# Here is an example of a mnemonic error that will
# not be caught by the syntax checker, but will
# be caught by the mnemonic checker
cmd("FAKECAM NOOOP")

# Here is an example of using variable expansion within
# a COSMOS Scripting API call.  The mnemonic checker will
# flag this as a possible error, but it is really ok.
(1..4).each do |htr|
  check("FAKECAM THERMAL_STATUS HTR#{htr}ENBL == 'DSBL'")
end

