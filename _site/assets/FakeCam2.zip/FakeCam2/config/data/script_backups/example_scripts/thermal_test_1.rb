# Turn on power to the FakeCam and wait for it to connect
cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
wait(5)

# Test zone 1
# First make sure that the zone is enabled
cmd("FAKECAM HTRZONEENBL with ZONEID 'ZONE1', ENBL 'ENBL'")
wait_check("FAKECAM THERMAL_STATUS ZONE1ENBL == 'ENBL'", 5)

# Set the zone setpoint to the highest allowable value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT 20.0")

# Check that the setpoint was set correctly
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE1SETPT", 20.0, 0.1, 5)

# Check to see if the zone reaches the specified temperature
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP1", 20.0, 5.0, 60)

# Set the zone setpoint to the lowest allowable value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT -30.0")

# Check that the setpoint was set correctly
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE1SETPT", -30.0, 0.1, 5)

# Check to see if the zone reaches the specified temperature
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP1", -30.0, 5.0, 60)

# Test zone 2
# First make sure that the zone is enabled
cmd("FAKECAM HTRZONEENBL with ZONEID 'ZONE2', ENBL 'ENBL'")
wait_check("FAKECAM THERMAL_STATUS ZONE2ENBL == 'ENBL'", 5)

# Set the zone setpoint to the highest allowable value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE2', SETPT 20.0")

# Check that the setpoint was set correctly
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE2SETPT", 20.0, 0.1, 5)

# Check to see if the zone reaches the specified temperature
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP2", 20.0, 5.0, 60)

# Set the zone setpoint to the lowest allowable value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE2', SETPT -30.0")

# Check that the setpoint was set correctly
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE2SETPT", -30.0, 0.1, 5)

# Check to see if the zone reaches the specified temperature
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP2", -30.0, 5.0, 60)

# Test zone 3
# First make sure that the zone is enabled
cmd("FAKECAM HTRZONEENBL with ZONEID 'ZONE3', ENBL 'ENBL'")
wait_check("FAKECAM THERMAL_STATUS ZONE3ENBL == 'ENBL'", 5)

# Set the zone setpoint to the highest allowable value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE3', SETPT 20.0")

# Check that the setpoint was set correctly
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE2SETPT", 20.0, 0.1, 5)

# Check to see if the zone reaches the specified temperature
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP3", 20.0, 5.0, 60)

# Set the zone setpoint to the lowest allowable value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE3', SETPT -30.0")

# Check that the setpoint was set correctly
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE3SETPT", -30.0, 0.1, 5)

# Check to see if the zone reaches the specified temperature
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP3", -30.0, 5.0, 60)

# Test zone 4
# First make sure that the zone is enabled
cmd("FAKECAM HTRZONEENBL with ZONEID 'ZONE4', ENBL 'ENBL'")
wait_check("FAKECAM THERMAL_STATUS ZONE4ENBL == 'ENBL'", 5)

# Set the zone setpoint to the highest allowable value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE4', SETPT 20.0")

# Check that the setpoint was set correctly
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE4SETPT", 20.0, 0.1, 5)

# Check to see if the zone reaches the specified temperature
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP4", 20.0, 5.0, 60)

# Set the zone setpoint to the lowest allowable value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE4', SETPT -30.0")

# Check that the setpoint was set correctly
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE4SETPT", -30.0, 0.1, 5)

# Check to see if the zone reaches the specified temperature
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP4", -30.0, 5.0, 60)

# Turn off power to the FakeCam
cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")

















































