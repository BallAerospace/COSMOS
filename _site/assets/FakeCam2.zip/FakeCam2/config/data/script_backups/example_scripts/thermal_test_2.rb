def check_setpoint(zone, setpoint)
  # Set the zone setpoint to the specified value
  cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE#{zone}', SETPT #{setpoint}")

  # Check that the setpoint was set correctly
  wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE#{zone}SETPT", setpoint, 0.1, 5)

  # Check to see if the zone reaches the specified temperature
  wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP#{zone}", setpoint, 5.0, 60)
end

def check_operational_range(zone)
  # First make sure that the zone is enabled
  cmd("FAKECAM HTRZONEENBL with ZONEID 'ZONE#{zone}', ENBL 'ENBL'")
  wait_check("FAKECAM THERMAL_STATUS ZONE#{zone}ENBL == 'ENBL'", 5)

  # Now test the zone at the highest value in the operational range
  check_setpoint(zone, 20.0)

  # Now test the zone at the lowest value in the operational range
  check_setpoint(zone, -30.0)
end


# Turn on power to the FakeCam and wait for it to connect
cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
wait(5)

# Test all 4 heaters
check_operational_range(1)
check_operational_range(2)
check_operational_range(3)
check_operational_range(4)

# Turn off power to the FakeCam
cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")
