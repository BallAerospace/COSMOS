# This is a constant
CONSTANT = 5
puts("CONSTANT has scope: #{defined?(CONSTANT)}")

# This is a local variable
local_var = 1234
puts("local_var has scope: #{defined?(local_var)}")

# This is a global variable
$global_var = 'some_val'
puts("$global_var has scope: #{defined?($global_var)}")

class ExampleClass
  # This is an instance variable
  @instance_var = 0

  # This is a class variable
  @@class_var = ''

  def self.put_var_scope()
    puts("@instance_var has scope: #{defined?(@instance_var)}")
    puts("@@class_var has scope: #{defined?(@@class_var)}")
  end
end

ExampleClass.put_var_scope()
