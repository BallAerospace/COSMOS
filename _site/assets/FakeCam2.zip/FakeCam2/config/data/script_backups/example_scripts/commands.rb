# Send a command to turn the FakeCam STE power supply on
cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
wait(5)

# Send a command to set a heater zone setpoint.  Note
# how the ZONEID parameter state is a string in single quotes,
# while the SETPT parameter is just a floating point number.
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT 5.0")

# Send the setpoint command again, but try it with a setpoint that
# is outside of the valid range.  This line will cause the script
# to stop in error!  Click on the "go" button to continue.
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT 25.0")

# Now force COSMOS to send the command with an invalid range.
# This WILL be sent, even if it's not safe!
cmd_no_range_check("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT 25.0")

# Now send the shutter position command.  This command
# is hazardous, so COSMOS will pop up a box asking the user if you
# want to continue.  Click ok to continue.
cmd("FAKECAM SHUTTERPOS with POS 'OPEN'")

# Send the shutter command again, but this time disable the hazardous
# check.  The command will go through without asking for verification!
cmd_no_hazardous_check("FAKECAM SHUTTERPOS with POS 'CLOSED'")

# Turn FakeCam back off
cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")
