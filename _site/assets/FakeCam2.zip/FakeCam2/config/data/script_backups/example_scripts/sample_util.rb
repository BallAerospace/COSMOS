def util_method
  puts "Executing util_method"
  wait(5)
  puts "Done executing util_method"
end