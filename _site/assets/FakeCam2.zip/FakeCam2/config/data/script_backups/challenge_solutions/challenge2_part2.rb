# Turn on power to the FakeCam and wait for it to connect
cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
wait(5)

# Make sure the heater zone is enabled 
cmd("FAKECAM HTRZONEENBL with ZONEID 'ZONE1', ENBL 'ENBL'")
wait_check("FAKECAM THERMAL_STATUS ZONE1ENBL == 'ENBL'", 5)

# Set the zone setpoint to the max value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT 20.0")
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE1SETPT", 20.0, 0.1, 5)

# Check to see if the temperature reaches the desired value
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP1", 20.0, 5.0, 60)

# Now set the zone setpoint to the min value
cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT -30.0")
wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE1SETPT", -30.0, 0.1, 5)

# Check to see if the temperature reaches the desired value
wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP1", -30.0, 5.0, 60)

# Turn off power to the FakeCam
cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")
