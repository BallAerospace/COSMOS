# Turn on power to the FakeCam and wait for it to connect
cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
wait(5)

# Open the shutter
cmd_no_hazardous_check("FAKECAM SHUTTERPOS with POS 'OPEN'")
wait_check("FAKECAM HEALTH_STATUS SHUTTERPOS == 'OPEN'", 5)

# Take an image
cmd("FAKECAM TAKEIMAGE")

# Wait a couple seconds for imaging to start.
wait("FAKECAM HEALTH_STATUS IMAGEINPROG == 'IMAGING'", 2)

# Now wait for imaging to complete.
wait_check("FAKECAM HEALTH_STATUS IMAGEINPROG == 'NOTIMAGING'", 60) 

# Turn off power to the FakeCam
cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")
