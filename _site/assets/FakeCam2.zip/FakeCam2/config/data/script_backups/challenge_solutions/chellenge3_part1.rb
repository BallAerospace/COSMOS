# $Id$

# LEGAL_RB_CSU_COMMERCIAL
#
# Commercial Software Rights Notice
#
# This Computer Software Unit (CSU) was developed at private expense by 
# Ball Aerospace & Technologies Corp. and qualifies as commercial computer 
# software under the applicable acquisition regulations governing the 
# contract under which this software has been delivered.  Use, duplication,
# or disclosure is subject to the restrictions referenced in the Software 
# Rights Notice in the controlling CSU of the Computer Software Configuration
# Item of which this CSU is a part.   This is an unpublished work, copyright 2012, 
# Ball Aerospace & Technologies Corp.   With respect to non-Government 
# recipients, Ball Aerospace reserves all of its proprietary rights in this 
# software.
#
# LEGAL_END
#
# Author: Donald Hall
#
# This is a sample thermal test for the FakeCam camera simulator
#

require 'cosmos/tools/test_runner/test'

class FakeCamThermalTest < Cosmos::Test

  def setup
    puts "Running FakeCamThermalTest setup"  
    puts "FakeCamThermalTest setup complete"
  end

  def teardown
    puts "Running FakeCamThermalTest teardown"
    puts "FakeCamThermalTest teardown complete"
  end

  def check_enbl_dsbl(zone)
    # Turn off the heater
    cmd("FAKECAM HTROVERRIDE with ZONEID 'ZONE#{zone}', ENBL 'DSBL'")
    
    # Check that zone control and the heater are both disabled
    wait_check("FAKECAM THERMAL_STATUS ZONE#{zone}ENBL == 'DSBL'", 5)
    wait_check("FAKECAM THERMAL_STATUS HTR#{zone}ENBL == 'DSBL'", 5)
    
    # Turn on the heater
    cmd("FAKECAM HTROVERRIDE with ZONEID 'ZONE#{zone}', ENBL 'ENBL'")
    
    # Check that the heater is enabled
    wait_check("FAKECAM THERMAL_STATUS HTR#{zone}ENBL == 'ENBL'", 5)
    
    # Enable zone control
    cmd("FAKECAM HTRZONEENBL with ZONEID 'ZONE#{zone}', ENBL 'ENBL'")
    
    # Check that zone control is enabled
    wait_check("FAKECAM THERMAL_STATUS ZONE#{zone}ENBL == 'ENBL'", 5)
  end

  def test_enbl_dsbl
    puts "Running test_enbl_dsbl"
    Cosmos::Test.puts "This test verifies requirement 1004"

    # Perform this test for all 4 heaters
    check_enbl_dsbl(1)
    check_enbl_dsbl(2)
    check_enbl_dsbl(3)
    check_enbl_dsbl(4)

    puts "test_enbl_dsbl complete"
  end

  def check_setpoint(zone, setpoint)
    # Set the zone setpoint to the specified value
    cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE#{zone}', SETPT #{setpoint}")
  
    # Check that the setpoint was set correctly
    wait_check_tolerance("FAKECAM THERMAL_STATUS ZONE#{zone}SETPT", setpoint, 0.1, 5)
  
    # Check to see if the zone reaches the specified temperature
    wait_check_tolerance("FAKECAM THERMAL_STATUS TEMP#{zone}", setpoint, 5.0, 60)
  end
  
  def check_operational_range(zone)
    # First make sure that the zone is enabled
    cmd("FAKECAM HTRZONEENBL with ZONEID 'ZONE#{zone}', ENBL 'ENBL'")
    wait_check("FAKECAM THERMAL_STATUS ZONE#{zone}ENBL == 'ENBL'", 5)
  
    # Now test the zone at the highest value in the operational range
    check_setpoint(zone, 20.0)
  
    # Now test the zone at the lowest value in the operational range
    check_setpoint(zone, -30.0)
  end

  def test_setpoints
    puts "Running test_setpoints"
    Cosmos::Test.puts "This test verifies requirement 1005"

    # Test all 4 heaters
    check_operational_range(1)
    check_operational_range(2)
    check_operational_range(3)
    check_operational_range(4)

    puts "test_setpoints complete"
  end

end

