stop_logging()
wait 5

start_logging('ALL', "example")

puts "Starting log at #{Time.now}"

wait 5

cmd("FAKECAMSTE PSENBL with ENBL 'ENBL'")
wait 30

cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT -5.0")
wait 60

cmd("FAKECAM HTRZONESETPT with ZONEID 'ZONE1', SETPT 10.0")
wait 60

cmd("FAKECAMSTE PSENBL with ENBL 'DSBL'")
wait 5

puts "Stopping log at #{Time.now}"

stop_logging()
wait 5

start_logging()