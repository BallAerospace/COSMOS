# $Id$

# LEGAL_RB_CSU_COMMERCIAL
#
# Commercial Software Rights Notice
#
# This Computer Software Unit (CSU) was developed at private expense by 
# Ball Aerospace & Technologies Corp. and qualifies as commercial computer 
# software under the applicable acquisition regulations governing the 
# contract under which this software has been delivered.  Use, duplication,
# or disclosure is subject to the restrictions referenced in the Software 
# Rights Notice in the controlling CSU of the Computer Software Configuration
# Item of which this CSU is a part.   This is an unpublished work, copyright 2012, 
# Ball Aerospace & Technologies Corp.   With respect to non-Government 
# recipients, Ball Aerospace reserves all of its proprietary rights in this 
# software.
#
# LEGAL_END
#
# Author: Donald Hall
#
# Simulates a very simple STE target-- a power supply for the "Fake Cam"
# simulated instrument. The "Fake Cam STE" can do the following:
#   1.  Turn a simulated power supply on or off to apply/remove power to/from
#       FakeCam
#   2.  Send a simulated pulse to reset FakeCam.
#

require 'cosmos'
require 'cosmos\utilities\simulated_target'

class FakeCamSte < Cosmos::SimulatedTarget

  PS_DSBL = 0
  PS_ENBL = 1
  PS_VOLTAGE_OFF = 0.0
  PS_VOLTAGE_ON  = 28.0
  PS_CURRENT_OFF = 0.0
  PS_CURRENT_ON = 4.3

  def initialize (target_name)
    super(target_name)
    
    packet = @tlm_packets['HEALTH_STATUS']
    packet.enable_method_missing
    packet.cmdacceptcnt = 0
    packet.cmdrejectcnt = 0
    packet.psenbl = PS_DSBL
    @ps_voltage = PS_VOLTAGE_OFF
    @ps_current = PS_CURRENT_OFF
    $fake_cam_powered_on = false
    $fake_cam_in_reset = true
  end
  
  def set_rates
    set_rate('HEALTH_STATUS', 100)
  end
  
  def write (packet)
    name = packet.packet_name.upcase
    
    hs_packet = @tlm_packets['HEALTH_STATUS']
    
    case name
    when 'PSENBL'
      hs_packet.cmdacceptcnt += 1
      if packet.read('enbl') == 'ENBL'        
        hs_packet.psenbl = PS_ENBL
        @ps_voltage = PS_VOLTAGE_ON
        @ps_current = PS_CURRENT_ON
        $fake_cam_powered_on = true
      else
        hs_packet.psenbl = PS_DSBL
        @ps_voltage = PS_VOLTAGE_OFF
        @ps_current = PS_CURRENT_OFF
        $fake_cam_powered_on = false
        $fake_cam_in_reset = true
      end
    when 'RESETCAM'
      hs_packet.cmdacceptcnt += 1
      $fake_cam_in_reset = true
    else
      hs_packet.cmdrejectcnt += 1
    end
  end
  
  def read (count_100hz, time)
    pending_packets = get_pending_packets(count_100hz)
    
    pending_packets.each do |packet|
      case packet.packet_name        
      when 'HEALTH_STATUS'        
        packet.timesec = time.tv_sec
        packet.timeus  = time.tv_usec
        packet.psvoltage = (@ps_voltage - 0.05 + (rand / 10.0)).abs
        packet.pscurrent = (@ps_current - 0.05 + (rand / 10.0)).abs
      end        
    end
        
    return pending_packets
  end

end