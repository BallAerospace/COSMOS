# $Id$

# LEGAL_RB_CSU_COMMERCIAL
#
# Commercial Software Rights Notice
#
# This Computer Software Unit (CSU) was developed at private expense by 
# Ball Aerospace & Technologies Corp. and qualifies as commercial computer 
# software under the applicable acquisition regulations governing the 
# contract under which this software has been delivered.  Use, duplication,
# or disclosure is subject to the restrictions referenced in the Software 
# Rights Notice in the controlling CSU of the Computer Software Configuration
# Item of which this CSU is a part.   This is an unpublished work, copyright 2012, 
# Ball Aerospace & Technologies Corp.   With respect to non-Government 
# recipients, Ball Aerospace reserves all of its proprietary rights in this 
# software.
#
# LEGAL_END
#
# Author: Donald Hall
#
# Simulates a very simple instrument called "FakeCam".  The FakeCam
# instrument can do the following:
#   1.  Open/close a simulated shutter.
#   2.  Take "images"
#   3.  Simulate a thermal control system.  The thermal control system
#       consists of 4 heaters and 4 temp sensors, with each heater mapped
#       to a temp sensor to form a "zone".  When zone control is enabled,
#       the simulated software will enable/disable the heater to keep the 
#       temperature at some setpoint.  When the heater goes on, temp goes up,
#       when the heater is off, temp goes down.  No fancy modelling, just movement.
#

require 'cosmos'
require 'cosmos\utilities\simulated_target'

class HeaterZone
  HTR_DSBL = 0
  HTR_ENBL = 1
  MIN_TEMP = -50.0
  MAX_TEMP = 40.0
  DEADBAND = 1.0
  MIN_RATE_OF_CHANGE = -1.0
  MAX_RATE_OF_CHANGE = 1.0
  RATE_OF_CHANGE_ACCEL = 0.2 + (rand() / 5.0)

  attr_reader :temp
  attr_accessor :setpt, :ctrl_enbl, :htr_enbl

  def initialize(start_temp, htr_broken = false)
    @htr_enbl  = HTR_DSBL
    @temp      = start_temp + ((rand() * 10) - 5)
    @setpt     = start_temp 
    @ctrl_enbl = HTR_ENBL
    @temp_rate_of_change = (rand() / 10.0)

    # If the heater is "broken", it can't reach the desired range of temperatures.
    @min_temp = MIN_TEMP
    if htr_broken
      @max_temp = 0.0
    else
      @max_temp = MAX_TEMP
    end
  end

  def update
    # First simulate the effects of the heaters being on/off.  If the heater
    # is on, the temp goes up.  If it's off, it goes down.
    if @htr_enbl == HTR_ENBL
      # Adjust the rate of change. The rate of change should slow once we approach the max temperature.
      if (@temp + 10) < @max_temp
        @temp_rate_of_change += RATE_OF_CHANGE_ACCEL
        @temp_rate_of_change = MAX_RATE_OF_CHANGE if @temp_rate_of_change > MAX_RATE_OF_CHANGE
      else
        @temp_rate_of_change -= 0.05
        @temp_rate_of_change = 0.1 if @temp_rate_of_change < 0.1
      end
    else
      # Adjust the rate of change. The rate of change should slow once we approach the min temperature.
      if (@temp - 10) > @min_temp
        @temp_rate_of_change -= RATE_OF_CHANGE_ACCEL
        @temp_rate_of_change = MIN_RATE_OF_CHANGE if @temp_rate_of_change < MIN_RATE_OF_CHANGE
      else
        @temp_rate_of_change += 0.05
        @temp_rate_of_change = -0.1 if @temp_rate_of_change > -0.1
      end      
    end

    # Now adjust the temperature.
    @temp += @temp_rate_of_change
    @temp = @max_temp if @temp > @max_temp
    @temp = @min_temp if @temp < @min_temp

    # Now execute "zone control" (if enabled)
    if @ctrl_enbl == HTR_ENBL
      if @temp > @setpt + DEADBAND
        # Turn the heater off.
        @htr_enbl = HTR_DSBL
      elsif @temp < @setpt - DEADBAND
        # Turn the heater on.
        @htr_enbl = HTR_ENBL
      end
    end
  end
end

class FakeCam < Cosmos::SimulatedTarget

  NOT_IMAGING = 0
  IMAGING     = 1
  SHUTTER_CLOSED = 0
  SHUTTER_OPEN   = 1

  IMG_PKT_DATA_SIZE_BYTES = 4000

  def initialize (target_name)
    super(target_name)

    # Get list of images available
    image_dir = File.join(::Cosmos::USERPATH, 'config', 'data', 'images')
    image_pattern = File.join(image_dir, "*.jpg")
    @image_list = Dir.glob(image_pattern)
    # Shuffle the array so images come up in a different order each time...
    @image_list.shuffle!
    @image_index = 0

    reset()
    @hs_packet = @tlm_packets['HEALTH_STATUS']
  end
  
  def set_rates
    set_rate('HEALTH_STATUS', 100)
    set_rate('THERMAL_STATUS', 100)
    set_rate('IMAGE_DATA', 10)
  end

  def reset()
    # Init H&S
    packet = @tlm_packets['HEALTH_STATUS']
    packet.cmdacceptcnt = 0
    packet.cmdrejectcnt = 0
    packet.imagecnt     = 0 
    packet.imageinprog  = NOT_IMAGING
    packet.shutterpos   = SHUTTER_CLOSED

    # Init heaters.
    @heater_zones = []
    @heater_zones << HeaterZone.new(10)
    @heater_zones << HeaterZone.new(-23)
    @heater_zones << HeaterZone.new(-11)
    @heater_zones << HeaterZone.new(19)

    # Init imaging
    @img_data = []
    @img_in_prog = NOT_IMAGING
    @img_num = 0
    @img_num_pkts = 0
    @img_pkt_num = 0
    @img_name = "\000"
  end
  
  def write (packet)
    name = packet.packet_name.upcase
    
    case name
    when 'NOOP'
      @hs_packet.cmdacceptcnt += 1
    when 'SHUTTERPOS'
      @hs_packet.cmdacceptcnt += 1
      @hs_packet.shutterpos = packet.read('POS', :RAW)
    when 'TAKEIMAGE'
      if ((@hs_packet.read('SHUTTERPOS', :RAW) == SHUTTER_OPEN) and
          (@img_in_prog != IMAGING))
        #begin
          # Increment the index so we send the next image.
          @image_index = (@image_index + 1) % @image_list.size
          
          # Read the image data
          @image_data = ""
          File.open(@image_list[@image_index], 'rb') {|file| @image_data = file.read()}
          @img_num += 1
          @img_num_pkts = (@image_data.size + (IMG_PKT_DATA_SIZE_BYTES-1)) / IMG_PKT_DATA_SIZE_BYTES
          @img_pkt_num = 0
          @img_in_prog = IMAGING
          @img_name = File.basename(@image_list[@image_index]) + "\000"         
          
          # Update tlm
          @hs_packet.cmdacceptcnt += 1
          @hs_packet.imagecnt += 1
        #rescue
        #  @hs_packet.cmdrejectcnt += 1
        #end
      else
        # Either we're already imaging, or the shutter isn't open.  Either way, 
        # reject this command.
        @hs_packet.cmdrejectcnt += 1
      end
    when 'HTRZONEENBL'
      zone = packet.read('ZONEID', :RAW)
      enbl = packet.read('ENBL', :RAW)
      if zone < @heater_zones.size()
        @hs_packet.cmdacceptcnt += 1
        @heater_zones[zone].ctrl_enbl = enbl
      else
        @hs_packet.cmdrejectcnt += 1
      end
    when 'HTRZONESETPT'
      zone = packet.read('ZONEID', :RAW)
      setpt = packet.read('SETPT', :RAW)
      if zone < @heater_zones.size() and 
         (HeaterZone::MIN_TEMP..HeaterZone::MAX_TEMP).include?(setpt)
         @heater_zones[zone].setpt = setpt
         @hs_packet.cmdacceptcnt += 1
      else
        @hs_packet.cmdrejectcnt += 1
      end
    when 'HTROVERRIDE'
      zone = packet.read('ZONEID', :RAW)
      enbl = packet.read('ENBL', :RAW)
      if zone < @heater_zones.size()
        @hs_packet.cmdacceptcnt += 1
        @heater_zones[zone].ctrl_enbl = 0
        @heater_zones[zone].htr_enbl = enbl
      else
        @hs_packet.cmdrejectcnt += 1
      end
    else
      @hs_packet.cmdrejectcnt += 1
    end
  end
  
  def read (count_100hz, time)
    raise Errno::ECONNRESET unless $fake_cam_powered_on
    if $fake_cam_in_reset
      reset()
      $fake_cam_in_reset = false
    end

    pending_packets = get_pending_packets(count_100hz)
    ready_packets = []
    
    pending_packets.each do |packet|
      case packet.packet_name        
      when 'HEALTH_STATUS'        
        packet.timesec = time.tv_sec
        packet.timeus  = time.tv_usec
        packet.imageinprog = @img_in_prog
        ready_packets << packet
      when 'THERMAL_STATUS'
        packet.timesec = time.tv_sec
        packet.timeus  = time.tv_usec
        @heater_zones.each_with_index do |zone, i|
          zone.update()
          packet.write("TEMP#{i+1}", zone.temp)
          packet.write("ZONE#{i+1}ENBL", zone.ctrl_enbl)
          packet.write("ZONE#{i+1}SETPT", zone.setpt)
          packet.write("HTR#{i+1}ENBL", zone.htr_enbl)
        end
        ready_packets << packet
      when 'IMAGE_DATA'
        # Only send image data packets if we're imaging!
        if @img_in_prog == IMAGING
          packet.timesec = time.tv_sec
          packet.timeus  = time.tv_usec
          packet.imagenum = @img_num
          packet.numpkts  = @img_num_pkts
          data_start = @img_pkt_num * IMG_PKT_DATA_SIZE_BYTES
          data_stop = data_start + IMG_PKT_DATA_SIZE_BYTES-1
          if data_stop > @image_data.size-1
            data_stop = @image_data.size-1
          end 
          packet.imagedata = @image_data[(data_start)..(data_stop)]
          @img_pkt_num += 1
          packet.pktnum = @img_pkt_num
          packet.pktbytes = data_stop - data_start + 1
          packet.imagename = @img_name

          # Check to see if the image transmit is complete.
          @img_in_prog = NOT_IMAGING if @img_pkt_num >= @img_num_pkts
          ready_packets << packet
        end
      end
    end
        
    #return pending_packets
    return ready_packets
  end

end
