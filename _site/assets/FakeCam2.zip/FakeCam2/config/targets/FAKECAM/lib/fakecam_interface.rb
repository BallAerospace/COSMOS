# $Id$

# LEGAL_RB_CSU_MIXED_2008
#
# Ball Aerospace & Technologies Corp. Proprietary Information
#
# The information contained herein is the private property of 
# Ball Aerospace & Technologies Corp. that is being made available 
# to the recipient under the terms of a nondisclosure agreement or 
# by other special arrangement.  It may not be used, in whole or in 
# part, except for the limited purpose for which it has been furnished.  
# It may not be distributed or reproduced, except as specifically 
# authorized by Ball Aerospace and with this legend conspicuously 
# attached.  This information is exempt from public disclosure 
# under 5 U.S.C. 552(b)(4), and its use by Government personnel 
# is subject to the restrictions imposed by 18 U.S.C. 1905.
#
# This source code module was developed with funds provided by a
# DOD Program and internal funding, but the module was not requested 
# by or delivered on that program.  Accordingly, Ball Aerospace 
# retains all of the rights and title to this module.
#
# LEGAL_END
#
# Author: Donald Hall
#
# This file contains the implementation for the 
# FakeCam interface class.  The Fake Cam interface is basically the
# same as the simulated_target_interface, except that it's been
# modified so that the target will not connect if the FakeCam is not
# "powered" (i.e. if simulated power in the FakeCamSte target is not turned on.)
#

require 'cosmos'
require 'cosmos/interfaces/simulated_target_interface'

# SimulatedTargetInterface class
#
# Provides an interface class that provides simulated telemetry and
# command responses.
# 
class FakecamInterface < Cosmos::SimulatedTargetInterface
  
  def initialize (sim_target_file)
    #Initialize Base Class
    super(sim_target_file)
  end
  
  def connect
    if $fake_cam_powered_on
      @connected  = super
    else
      @connected = false
      raise Errno::ECONNREFUSED
    end

    # Reset the next time tick so we don't spam out telemetry for the time
    # we spent disconnected.
    @next_tick_time = Time.now + 0.01
    return @connected
  end
  
  def read
    if $fake_cam_powered_on
      return super if @connected
    else
      disconnect()
      raise Errno::ECONNRESET
    end
    return nil
  end
end