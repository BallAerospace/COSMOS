#!/usr/bin/env ruby
# encoding: ascii-8bit

# Ball Aerospace & Technologies Corp. Proprietary Information
#
# The information contained herein is the private property of Ball Aerospace &
# Technologies Corp. that is being made available to the recipient under the
# terms of a nondisclosure agreement or by other special arrangement.  It may
# not be used, in whole or in part, except for the limited purpose for which it
# has been furnished. It may not be distributed or reproduced, except as
# specifically authorized by Ball Aerospace and with this legend conspicuously
# attached.  This information is exempt from public disclosure under 5 U.S.C.
# 552(b)(4), and its use by Government personnel is subject to the restrictions
# imposed by 18 U.S.C. 1905.
#
# This source code module was developed with funds provided by
# Capital funding under charge number 11418.13.001.

require 'cosmos'
require 'cosmos/tools/tlm_grapher/tlm_grapher'
Cosmos::TlmGrapher.run
